﻿Public Class Form1

    Dim Total1 As Integer
    Dim Total2 As Integer
    Dim Total3 As Integer
    Dim Total4 As Decimal
    Dim Total5 As Decimal
    Dim btnPlusClick As Boolean
    Dim btnEqualsClick As Boolean
    Dim btnMinusClick As Boolean
    Dim btnMultiplyClick As Boolean
    Dim btnDivClick As Boolean


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToParent()
    End Sub

    Private Sub btnOne_Click(sender As Object, e As EventArgs) Handles btnOne.Click
        txtDisplay.Text = txtDisplay.Text & btnOne.Text
    End Sub

    Private Sub btnTwo_Click(sender As Object, e As EventArgs) Handles btnTwo.Click
        txtDisplay.Text = txtDisplay.Text & btnTwo.Text
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        txtDisplay.Text = txtDisplay.Text & btn3.Text
    End Sub

    Private Sub btnFour_Click(sender As Object, e As EventArgs) Handles btnFour.Click
        txtDisplay.Text = txtDisplay.Text & btnFour.Text
    End Sub

    Private Sub btnFive_Click(sender As Object, e As EventArgs) Handles btnFive.Click
        txtDisplay.Text = txtDisplay.Text & btnFive.Text
    End Sub

    Private Sub btnSix_Click(sender As Object, e As EventArgs) Handles btnSix.Click
        txtDisplay.Text = txtDisplay.Text & btnSix.Text
    End Sub

    Private Sub btn7_Click(sender As Object, e As EventArgs) Handles btn7.Click
        txtDisplay.Text = txtDisplay.Text & btn7.Text
    End Sub

    Private Sub bnt8_Click(sender As Object, e As EventArgs) Handles bnt8.Click
        txtDisplay.Text = txtDisplay.Text & bnt8.Text
    End Sub

    Private Sub btn9_Click(sender As Object, e As EventArgs) Handles btn9.Click
        txtDisplay.Text = txtDisplay.Text & btn9.Text
    End Sub

    Private Sub btnZero_Click(sender As Object, e As EventArgs) Handles btnZero.Click
        txtDisplay.Text = txtDisplay.Text & btnZero.Text
    End Sub

    Sub btnPlus_Click(sender As Object, e As EventArgs) Handles btnPlus.Click
        btnPlusClick = True
        Total1 = Total1 + Val(txtDisplay.Text)
        txtDisplay.Clear()
    End Sub

    Sub BtnMinus_Click(sender As Object, e As EventArgs) Handles BtnMinus.Click
        btnMinusClick = True
        Total1 = Val(txtDisplay.Text) - Total1
        txtDisplay.Clear()
    End Sub

    Sub btnMultiply_Click(sender As Object, e As EventArgs) Handles btnMultiply.Click
        btnMultiplyClick = True
        Total1 = Total1 * Val(txtDisplay.Text)
        txtDisplay.Clear()
    End Sub

    Sub btnDiv_Click(sender As Object, e As EventArgs) Handles btnDiv.Click
        btnDivClick = True
        Total1 = Total1 / Val(txtDisplay.Text)
        txtDisplay.Clear()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtDisplay.Clear()
    End Sub

    Private Sub txtDisplay_TextChanged(sender As Object, e As EventArgs) Handles txtDisplay.TextChanged
        'txtDisplay.Text = ""
    End Sub

    Sub btnEquals_Click(sender As Object, e As EventArgs) Handles btnEquals.Click
        If btnPlusClick Then
            Total2 = Total1 + Val(txtDisplay.Text)
            txtDisplay.Text = Total2
            Total1 = 0
            btnPlusClick = False

        ElseIf BtnMinusClick Then
            Total3 = Total1 - Val(txtDisplay.Text)
            txtDisplay.Text = Total3
            Total1 = 0
            btnMinusClick = False

        ElseIf btnMultiplyClick Then
            Total4 = Total1 * Val(txtDisplay.Text)
            txtDisplay.Text = Total4
            'Total1 = 0
            btnMultiplyClick = False

        ElseIf btnDivClick Then
            Total5 = Total1 / Val(txtDisplay.Text)
            txtDisplay.Text = Total5
            'Total1 = 0
            btnDivClick = False
        End If

    End Sub
End Class
