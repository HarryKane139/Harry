﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtDisplay = New System.Windows.Forms.TextBox()
        Me.btnOne = New System.Windows.Forms.Button()
        Me.btnTwo = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btnFour = New System.Windows.Forms.Button()
        Me.btnFive = New System.Windows.Forms.Button()
        Me.btnSix = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.bnt8 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btnZero = New System.Windows.Forms.Button()
        Me.btnPlus = New System.Windows.Forms.Button()
        Me.BtnMinus = New System.Windows.Forms.Button()
        Me.btnEquals = New System.Windows.Forms.Button()
        Me.btnMultiply = New System.Windows.Forms.Button()
        Me.btnDiv = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtDisplay
        '
        Me.txtDisplay.BackColor = System.Drawing.SystemColors.Info
        Me.txtDisplay.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtDisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDisplay.ForeColor = System.Drawing.SystemColors.MenuText
        Me.txtDisplay.Location = New System.Drawing.Point(1, 2)
        Me.txtDisplay.Multiline = True
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.Size = New System.Drawing.Size(270, 89)
        Me.txtDisplay.TabIndex = 0
        '
        'btnOne
        '
        Me.btnOne.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnOne.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btnOne.FlatAppearance.BorderSize = 0
        Me.btnOne.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnOne.ForeColor = System.Drawing.SystemColors.InfoText
        Me.btnOne.Location = New System.Drawing.Point(29, 97)
        Me.btnOne.Name = "btnOne"
        Me.btnOne.Size = New System.Drawing.Size(34, 23)
        Me.btnOne.TabIndex = 1
        Me.btnOne.Text = "1"
        Me.btnOne.UseVisualStyleBackColor = False
        '
        'btnTwo
        '
        Me.btnTwo.Location = New System.Drawing.Point(85, 97)
        Me.btnTwo.Name = "btnTwo"
        Me.btnTwo.Size = New System.Drawing.Size(34, 23)
        Me.btnTwo.TabIndex = 2
        Me.btnTwo.Text = "2"
        Me.btnTwo.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Location = New System.Drawing.Point(137, 97)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(34, 23)
        Me.btn3.TabIndex = 3
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'btnFour
        '
        Me.btnFour.Location = New System.Drawing.Point(29, 144)
        Me.btnFour.Name = "btnFour"
        Me.btnFour.Size = New System.Drawing.Size(34, 23)
        Me.btnFour.TabIndex = 4
        Me.btnFour.Text = "4"
        Me.btnFour.UseVisualStyleBackColor = True
        '
        'btnFive
        '
        Me.btnFive.Location = New System.Drawing.Point(85, 143)
        Me.btnFive.Name = "btnFive"
        Me.btnFive.Size = New System.Drawing.Size(34, 23)
        Me.btnFive.TabIndex = 5
        Me.btnFive.Text = "5"
        Me.btnFive.UseVisualStyleBackColor = True
        '
        'btnSix
        '
        Me.btnSix.Location = New System.Drawing.Point(137, 143)
        Me.btnSix.Name = "btnSix"
        Me.btnSix.Size = New System.Drawing.Size(34, 23)
        Me.btnSix.TabIndex = 6
        Me.btnSix.Text = "6"
        Me.btnSix.UseVisualStyleBackColor = True
        '
        'btn7
        '
        Me.btn7.Location = New System.Drawing.Point(29, 196)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(34, 23)
        Me.btn7.TabIndex = 7
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = True
        '
        'bnt8
        '
        Me.bnt8.Location = New System.Drawing.Point(85, 195)
        Me.bnt8.Name = "bnt8"
        Me.bnt8.Size = New System.Drawing.Size(34, 23)
        Me.bnt8.TabIndex = 8
        Me.bnt8.Text = "8"
        Me.bnt8.UseVisualStyleBackColor = True
        '
        'btn9
        '
        Me.btn9.Location = New System.Drawing.Point(137, 195)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(34, 23)
        Me.btn9.TabIndex = 9
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = True
        '
        'btnZero
        '
        Me.btnZero.Location = New System.Drawing.Point(85, 243)
        Me.btnZero.Name = "btnZero"
        Me.btnZero.Size = New System.Drawing.Size(34, 23)
        Me.btnZero.TabIndex = 10
        Me.btnZero.Text = "0"
        Me.btnZero.UseVisualStyleBackColor = True
        '
        'btnPlus
        '
        Me.btnPlus.Location = New System.Drawing.Point(207, 97)
        Me.btnPlus.Name = "btnPlus"
        Me.btnPlus.Size = New System.Drawing.Size(34, 23)
        Me.btnPlus.TabIndex = 11
        Me.btnPlus.Text = "+"
        Me.btnPlus.UseVisualStyleBackColor = True
        '
        'BtnMinus
        '
        Me.BtnMinus.Location = New System.Drawing.Point(207, 144)
        Me.BtnMinus.Name = "BtnMinus"
        Me.BtnMinus.Size = New System.Drawing.Size(34, 23)
        Me.BtnMinus.TabIndex = 12
        Me.BtnMinus.Text = "-"
        Me.BtnMinus.UseVisualStyleBackColor = True
        '
        'btnEquals
        '
        Me.btnEquals.Location = New System.Drawing.Point(137, 243)
        Me.btnEquals.Name = "btnEquals"
        Me.btnEquals.Size = New System.Drawing.Size(34, 23)
        Me.btnEquals.TabIndex = 13
        Me.btnEquals.Text = "="
        Me.btnEquals.UseVisualStyleBackColor = True
        '
        'btnMultiply
        '
        Me.btnMultiply.Location = New System.Drawing.Point(207, 194)
        Me.btnMultiply.Name = "btnMultiply"
        Me.btnMultiply.Size = New System.Drawing.Size(34, 23)
        Me.btnMultiply.TabIndex = 14
        Me.btnMultiply.Text = "x"
        Me.btnMultiply.UseVisualStyleBackColor = True
        '
        'btnDiv
        '
        Me.btnDiv.Location = New System.Drawing.Point(207, 242)
        Me.btnDiv.Name = "btnDiv"
        Me.btnDiv.Size = New System.Drawing.Size(34, 23)
        Me.btnDiv.TabIndex = 15
        Me.btnDiv.Text = "/"
        Me.btnDiv.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(29, 242)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(34, 23)
        Me.btnClear.TabIndex = 16
        Me.btnClear.Text = "c"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(272, 292)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnDiv)
        Me.Controls.Add(Me.btnMultiply)
        Me.Controls.Add(Me.btnEquals)
        Me.Controls.Add(Me.BtnMinus)
        Me.Controls.Add(Me.btnPlus)
        Me.Controls.Add(Me.btnZero)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.bnt8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btnSix)
        Me.Controls.Add(Me.btnFive)
        Me.Controls.Add(Me.btnFour)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btnTwo)
        Me.Controls.Add(Me.btnOne)
        Me.Controls.Add(Me.txtDisplay)
        Me.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Name = "Form1"
        Me.Text = "Basic Calculator"
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtDisplay As TextBox
    Friend WithEvents btnOne As Button
    Friend WithEvents btnTwo As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents btnFour As Button
    Friend WithEvents btnFive As Button
    Friend WithEvents btnSix As Button
    Friend WithEvents btn7 As Button
    Friend WithEvents bnt8 As Button
    Friend WithEvents btn9 As Button
    Friend WithEvents btnZero As Button
    Friend WithEvents btnPlus As Button
    Friend WithEvents BtnMinus As Button
    Friend WithEvents btnEquals As Button
    Friend WithEvents btnMultiply As Button
    Friend WithEvents btnDiv As Button
    Friend WithEvents btnClear As Button
End Class
